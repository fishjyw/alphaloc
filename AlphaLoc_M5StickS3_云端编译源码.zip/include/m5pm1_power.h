#ifndef ALPHALOC_M5PM1_POWER_H
#define ALPHALOC_M5PM1_POWER_H

// Minimal M5PM1 (M5StickS3 PMIC) power control via ESP-IDF I2C.
// Enables the BOOST/Grove 5V output so the GPS module on PORT.A gets power.

void m5pm1_grove_5v_enable(void);

#endif
