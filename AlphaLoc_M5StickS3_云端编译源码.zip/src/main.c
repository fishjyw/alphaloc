#include <stdatomic.h>
#include <string.h>

#include "ble_client.h"
#if ALPHALOC_BLE_CONFIG
#include "ble_config_server.h"
#endif
#include "config.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_err.h"
#include "esp_log.h"
#if CONFIG_PM_ENABLE
#include "esp_pm.h"
#endif
#include "esp_rom_sys.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "gps.h"
#include "nvs_flash.h"
#if defined(ALPHALOC_M5PM1_GROVE_POWER)
#include "m5pm1_power.h"
#endif

#ifndef ALPHALOC_BATTERY_MONITOR
#define ALPHALOC_BATTERY_MONITOR 0
#endif

#if ALPHALOC_BATTERY_MONITOR
#include "battery.h"
#endif

#ifdef ALPHALOC_NEOPIXEL_PIN
#include "neopixel.h"
#endif

#ifndef ALPHALOC_WIFI_WEB
#define ALPHALOC_WIFI_WEB 1
#endif

#if ALPHALOC_WIFI_WEB
#include "wifi_web.h"
#endif

#define GPS_UART_NUM UART_NUM_1
#ifndef GPS_UART_TX_PIN
#error "GPS_UART_TX_PIN must be set via build_flags"
#endif
#ifndef GPS_UART_RX_PIN
#error "GPS_UART_RX_PIN must be set via build_flags"
#endif
#ifndef GPS_UART_BAUD
#define GPS_UART_BAUD 9600
#endif

#ifndef ALPHALOC_FAKE_GPS
#define ALPHALOC_FAKE_GPS 0
#endif

#ifndef ALPHALOC_LIGHT_SLEEP
#define ALPHALOC_LIGHT_SLEEP 0
#endif

static const char *TAG = "main";
static app_config_t s_cfg;
static atomic_bool s_config_window_active = false;

static bool get_location_for_send(gps_fix_t *out_fix) {
  gps_fix_t fix;
  if (gps_get_latest(&fix) && fix.valid) {
    *out_fix = fix;
    return true;
  }
  return false;
}

static void focus_update_cb(void *ctx) {
  app_config_t *cfg = (app_config_t *)ctx;
  app_config_t cfg_snapshot;
  if (!config_get_snapshot(cfg, &cfg_snapshot)) {
    cfg_snapshot = *cfg;
    config_validate(&cfg_snapshot);
  }
  gps_fix_t fix;
  if (!get_location_for_send(&fix)) {
    return;
  }
  int64_t now = esp_timer_get_time();
  if ((now - fix.last_fix_time_us) >
      (int64_t)cfg_snapshot.max_gps_age_s * 1000000LL) {
    return;
  }
  ble_client_send_location(&fix);
}

static void location_publisher_task(void *arg) {
  const app_config_t *cfg = (const app_config_t *)arg;
  while (true) {
    app_config_t cfg_snapshot;
    if (!config_get_snapshot(cfg, &cfg_snapshot)) {
      cfg_snapshot = *cfg;
      config_validate(&cfg_snapshot);
    }
    gps_fix_t fix;
    if (get_location_for_send(&fix)) {
      int64_t now = esp_timer_get_time();
      if ((now - fix.last_fix_time_us) <=
          (int64_t)cfg_snapshot.max_gps_age_s * 1000000LL) {
        ble_client_send_location(&fix);
      }
    }
    vTaskDelay(pdMS_TO_TICKS(cfg_snapshot.gps_interval_ms));
  }
}

static void config_window_task(void *arg) {
  app_config_t *cfg = (app_config_t *)arg;
  app_config_t cfg_snapshot;
  if (!config_get_snapshot(cfg, &cfg_snapshot)) {
    cfg_snapshot = *cfg;
    config_validate(&cfg_snapshot);
  }
#if ALPHALOC_BLE_CONFIG
  ble_config_server_start();
#endif
#if ALPHALOC_WIFI_WEB
  wifi_web_start(cfg);
#endif
  atomic_store(&s_config_window_active, true);
  vTaskDelay(pdMS_TO_TICKS(cfg_snapshot.config_window_s * 1000ULL));
#if ALPHALOC_BLE_CONFIG
  ble_config_server_stop();
#endif
#if ALPHALOC_WIFI_WEB
  wifi_web_stop();
#endif
  atomic_store(&s_config_window_active, false);
  vTaskDelete(NULL);
}

#if ALPHALOC_BATTERY_MONITOR
static void battery_task(void *arg) {
  (void)arg;
  battery_read_now();
  while (true) {
    vTaskDelay(pdMS_TO_TICKS(60000));
    battery_read_now();
  }
}
#endif

#ifdef ALPHALOC_NEOPIXEL_PIN
static void status_led_task(void *arg) {
  (void)arg;
  const uint8_t brightness = 8;
  const TickType_t on_ms = pdMS_TO_TICKS(150);
  const TickType_t off_ms = pdMS_TO_TICKS(150);
  const TickType_t cycle_ms = pdMS_TO_TICKS(5000);

  neopixel_init(ALPHALOC_NEOPIXEL_PIN, brightness);

  while (true) {
    TickType_t cycle_start = xTaskGetTickCount();

    // Camera status: green if connected and bonded, blue if connected only, red
    // if not connected.
    bool camera_connected = ble_client_is_connected();
    bool camera_bonded = ble_client_is_bonded();
    if (camera_connected && camera_bonded) {
      neopixel_set_rgb(0, 255, 0);
    } else if (camera_connected) {
      neopixel_set_rgb(0, 0, 255);
    } else {
      neopixel_set_rgb(255, 0, 0);
    }
    vTaskDelay(on_ms);
    neopixel_set_rgb(0, 0, 0);
    vTaskDelay(off_ms);

    // GPS status: green if currently locked, red if not. Fake GPS shows violet.
    gps_status_t gps_status;
    bool gps_ok = gps_get_status(&gps_status) && gps_status.has_lock;
    if (gps_ok) {
#if ALPHALOC_FAKE_GPS
      neopixel_set_rgb(128, 0, 255);
#else
      neopixel_set_rgb(0, 255, 0);
#endif
    } else {
      neopixel_set_rgb(255, 0, 0);
    }
    vTaskDelay(on_ms);
    neopixel_set_rgb(0, 0, 0);
    vTaskDelay(off_ms);

    // Battery status: green >50%, yellow >30%, red otherwise (if enabled).
#if ALPHALOC_BATTERY_MONITOR
    battery_status_t bat = {0};
    if (battery_get_status(&bat) && bat.valid) {
      if (bat.percent > 50.0f) {
        neopixel_set_rgb(0, 255, 0);
      } else if (bat.percent > 30.0f) {
        neopixel_set_rgb(255, 180, 0);
      } else {
        neopixel_set_rgb(255, 0, 0);
      }
      vTaskDelay(on_ms);
      neopixel_set_rgb(0, 0, 0);
      vTaskDelay(off_ms);
    }
#endif

    // Wi-Fi status: blue if web server/AP active.
#if ALPHALOC_WIFI_WEB
    if (atomic_load(&s_config_window_active)) {
      neopixel_set_rgb(0, 0, 255);
      vTaskDelay(on_ms);
      neopixel_set_rgb(0, 0, 0);
      vTaskDelay(off_ms);
    }
#endif

    TickType_t elapsed = xTaskGetTickCount() - cycle_start;
    if (elapsed < cycle_ms) {
      vTaskDelay(cycle_ms - elapsed);
    }
  }
}
#endif

void app_main(void) {
  ESP_LOGI(TAG, "AlphaLoc starting");

#if defined(ALPHALOC_M5PM1_GROVE_POWER)
  // M5StickS3: enable Grove PORT.A 5V rail so the GPS module is powered.
  m5pm1_grove_5v_enable();
  vTaskDelay(pdMS_TO_TICKS(200));
#endif

#if CONFIG_PM_ENABLE
  // Configure automatic light sleep (Issue 3.4)
  esp_pm_config_t pm_config = {
      .max_freq_mhz = 160,
      .min_freq_mhz = 40,
      .light_sleep_enable =
#if CONFIG_FREERTOS_USE_TICKLESS_IDLE && ALPHALOC_LIGHT_SLEEP
          true,
#else
          false,
#endif
  };
  esp_err_t pm_err = esp_pm_configure(&pm_config);
  if (pm_err == ESP_OK) {
    ESP_LOGI(TAG, "Power management: light sleep %s",
             pm_config.light_sleep_enable ? "enabled" : "disabled");
  } else {
    ESP_LOGW(TAG, "Power management configuration failed: %s",
             esp_err_to_name(pm_err));
  }
#if !ALPHALOC_LIGHT_SLEEP
  ESP_LOGI(TAG, "Automatic light sleep disabled for BLE camera reliability");
#elif !CONFIG_FREERTOS_USE_TICKLESS_IDLE
  ESP_LOGW(TAG, "Automatic light sleep disabled - enable "
                "CONFIG_FREERTOS_USE_TICKLESS_IDLE");
#endif
#else
  ESP_LOGW(TAG, "Power management disabled in sdkconfig - enable "
                "CONFIG_PM_ENABLE for light sleep");
#endif

#ifdef ALPHALOC_STEMMA_QT_DISABLE_PIN
  // Disable STEMMA QT power for lower power usage when unused.
  gpio_config_t stemma_cfg = {
      .pin_bit_mask = 1ULL << ALPHALOC_STEMMA_QT_DISABLE_PIN,
      .mode = GPIO_MODE_OUTPUT,
      .pull_up_en = GPIO_PULLUP_DISABLE,
      .pull_down_en = GPIO_PULLDOWN_DISABLE,
      .intr_type = GPIO_INTR_DISABLE,
  };
  ESP_ERROR_CHECK(gpio_config(&stemma_cfg));
  ESP_ERROR_CHECK(gpio_set_level(ALPHALOC_STEMMA_QT_DISABLE_PIN, 0));
#endif
  esp_err_t err = nvs_flash_init();
  if (err == ESP_ERR_NVS_NO_FREE_PAGES ||
      err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
#ifdef ALPHALOC_FACTORY_RESET
    if (ALPHALOC_FACTORY_RESET) {
      ESP_ERROR_CHECK(nvs_flash_erase());
      ESP_ERROR_CHECK(nvs_flash_init());
    } else {
      ESP_LOGW(TAG, "NVS needs erase but factory reset disabled; keeping data");
    }
#else
    ESP_LOGW(TAG,
             "NVS needs erase but factory reset flag not set; keeping data");
#endif
  } else if (err != ESP_OK) {
    ESP_LOGE(TAG, "NVS init failed: %s", esp_err_to_name(err));
  }

  config_load(&s_cfg);
  config_validate(&s_cfg);

  gps_config_t gps_cfg = {
      .uart_num = GPS_UART_NUM,
      .tx_pin = GPS_UART_TX_PIN,
      .rx_pin = GPS_UART_RX_PIN,
      .baud_rate = GPS_UART_BAUD,
      .update_interval_ms = s_cfg.gps_interval_ms,
  };
  gps_init(&gps_cfg);

  ble_client_init(&s_cfg);
  ble_client_set_focus_callback(focus_update_cb, &s_cfg);

  BaseType_t ret;
#if ALPHALOC_BATTERY_MONITOR
  battery_init();
  ret = xTaskCreate(battery_task, "battery", 3072, NULL, 4, NULL);
  if (ret != pdPASS) {
    ESP_LOGE(TAG, "Failed to create battery_task");
  }
#endif
  ret = xTaskCreate(location_publisher_task, "location_pub", 4096, &s_cfg, 5,
                    NULL);
  if (ret != pdPASS) {
    ESP_LOGE(TAG, "Failed to create location_publisher_task");
  }

  if (s_cfg.config_window_s > 0) {
    ret =
        xTaskCreate(config_window_task, "config_window", 4096, &s_cfg, 5, NULL);
    if (ret != pdPASS) {
      ESP_LOGE(TAG, "Failed to create config_window_task");
    }
  }
#ifdef ALPHALOC_NEOPIXEL_PIN
  ret = xTaskCreate(status_led_task, "status_led", 3072, &s_cfg, 1, NULL);
  if (ret != pdPASS) {
    ESP_LOGE(TAG, "Failed to create status_led_task");
  }
#endif
  ESP_LOGI(TAG, "AlphaLoc started");
}
