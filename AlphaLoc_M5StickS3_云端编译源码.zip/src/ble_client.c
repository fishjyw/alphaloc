#include "ble_client.h"

#include <math.h>
#include <string.h>

#include "ble_config_server.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "host/ble_att.h"
#include "host/ble_gap.h"
#include "host/ble_hs.h"
#include "host/ble_hs_adv.h"
#include "host/ble_hs_mbuf.h"
#include "host/ble_sm.h"
#include "host/ble_store.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
#include "store/config/ble_store_config.h"

static const char *TAG = "ble_client";

#ifndef ALPHALOC_VERBOSE
#define ALPHALOC_VERBOSE 0
#endif

#if ALPHALOC_VERBOSE
#define VLOGI(...) ESP_LOGI(TAG, __VA_ARGS__)
#define VLOGW(...) ESP_LOGW(TAG, __VA_ARGS__)
#else
#define VLOGI(...) ((void)0)
#define VLOGW(...) ((void)0)
#endif

#ifndef BLE_ERR_REM_USER_CONN_TERM
#define BLE_ERR_REM_USER_CONN_TERM 0x13
#endif

extern void ble_store_config_init(void);
extern int ble_store_util_delete_peer(const ble_addr_t *addr);

typedef struct {
  uint16_t conn_handle;
  uint16_t loc_svc_start;
  uint16_t loc_svc_end;
  uint16_t rem_svc_start;
  uint16_t rem_svc_end;
  uint16_t chr_dd11;
  uint16_t chr_dd21;
  uint16_t chr_dd30;
  uint16_t chr_dd31;
  uint16_t chr_ff02;
  uint16_t end_ff02;
  uint16_t cccd_ff02;
} ble_handles_t;

typedef enum {
  DISC_NONE = 0,
  DISC_LOC_SVC,
  DISC_ALL_SVC,
  DISC_LOC_CHR,
  DISC_ALL_CHR,
  DISC_REM_SVC,
  DISC_REM_CHR,
  DISC_REM_DSC,
} disc_state_t;

static const uint8_t SONY_MFG_PREFIX[4] = {0x2D, 0x01, 0x00, 0x03};

static ble_handles_t s_handles;
static disc_state_t s_disc_state;
static bool s_discovery_in_progress;
static uint32_t s_discovery_generation;
static bool s_discovery_reconnect_pending;
static bool s_dd21_in_progress;
static struct ble_npl_callout s_setup_retry_callout;
static bool s_setup_retry_initialized;
static uint8_t s_own_addr_type;
static const app_config_t *s_cfg;
static ble_focus_cb_t s_focus_cb;
static void *s_focus_ctx;
static bool s_require_tz_dst;
static int16_t s_tz_off_min;
static int16_t s_dst_off_min;
static bool s_connecting_camera;
static uint8_t s_dd21_retry;
static bool s_location_enabled;
static bool s_loc_enable_in_flight;
static uint32_t s_loc_enable_generation;
static bool s_dd21_ready;
static bool s_dd21_pending;
static bool s_encrypted;
static bool s_notify_pending;
static bool s_remote_disc_started;
static bool s_dsc_pending_ff02;
static bool s_dsc_in_progress;
static int64_t s_last_loc_enable_attempt_us;
static int64_t s_last_dd21_attempt_us;
static int64_t s_last_security_attempt_us;
static int64_t s_last_disc_attempt_us;
typedef enum {
  DSC_NONE = 0,
  DSC_FF02,
} dsc_target_t;
static dsc_target_t s_dsc_target;
static uint8_t s_dsc_retry_count;
static struct ble_npl_callout s_dsc_retry_callout;
static bool s_dsc_retry_initialized;
static int8_t s_last_chr_interest;
static bool s_ff02_cccd_deferred;
static bool s_ff02_cccd_sent;
#if ALPHALOC_VERBOSE
static bool s_payload_logged;
#endif
static bool s_bonded_camera;
static bool s_rebond_attempted;
static bool s_retried_disc_after_enc;

// The status/mailbox and focus callback pair are protected by this lock.
// Camera/GATT state belongs to the NimBLE host task after initialization.
static portMUX_TYPE s_client_lock = portMUX_INITIALIZER_UNLOCKED;
static struct {
  bool active;
  bool connected;
  bool bonded;
  bool ready;
  bool pending;
  bool wakeup_pending;
  gps_fix_t fix;
} s_client;
static struct ble_npl_callout s_location_callout;
static bool s_location_callout_initialized;

static bool client_active(void) {
  portENTER_CRITICAL(&s_client_lock);
  bool active = s_client.active;
  portEXIT_CRITICAL(&s_client_lock);
  return active;
}

// Host-only: invalidate pending data whenever the connection or setup changes.
// Clearing the copied fix also handles reused connection/attribute handles.
static void publish_camera_status(bool invalidate_location) {
  portENTER_CRITICAL(&s_client_lock);
  s_client.connected = s_client.active &&
                       s_handles.conn_handle != BLE_HS_CONN_HANDLE_NONE;
  s_client.bonded = s_client.connected && s_bonded_camera;
  s_client.ready = s_client.connected && s_location_callout_initialized &&
                   s_encrypted && s_location_enabled &&
                   !s_discovery_reconnect_pending && s_handles.chr_dd11 != 0 &&
                   (s_handles.chr_dd21 == 0 || s_dd21_ready);
  if (invalidate_location) {
    s_client.pending = false;
  }
  portEXIT_CRITICAL(&s_client_lock);
}

static void ble_start_scan(void);
static void schedule_dsc_retry(void);
static void try_start_ff02_dsc(uint16_t conn_handle);
static void try_start_pending_dsc(uint16_t conn_handle);
static void enable_location_updates(uint16_t conn_handle);
static void retry_camera_setup(void);
static void schedule_camera_setup_retry(void);
static void reset_camera_setup_state(void);
static bool enc_failure_needs_rebond(int status);
static int dd21_read_cb(uint16_t conn_handle,
                        const struct ble_gatt_error *error,
                        struct ble_gatt_attr *attr, void *arg);
static void delete_camera_bond(const struct ble_gap_conn_desc *desc);
static int cccd_write_cb(uint16_t conn_handle,
                         const struct ble_gatt_error *error,
                         struct ble_gatt_attr *attr, void *arg);
static int cccd_read_cb(uint16_t conn_handle,
                        const struct ble_gatt_error *error,
                        struct ble_gatt_attr *attr, void *arg);
typedef struct {
  const char *label;
  uint16_t handle;
  uint16_t chr_handle;
} cccd_ctx_t;

static cccd_ctx_t s_cccd_ff02_ctx = {"FF02", 0, 0};
static bool peer_is_bonded(const ble_addr_t *addr) {
  if (!addr) {
    return false;
  }
  ble_addr_t peers[MYNEWT_VAL(BLE_STORE_MAX_BONDS)];
  int num = 0;
  if (ble_store_util_bonded_peers(peers, &num,
                                  MYNEWT_VAL(BLE_STORE_MAX_BONDS)) != 0) {
    return false;
  }
  for (int i = 0; i < num; ++i) {
    if (memcmp(peers[i].val, addr->val, sizeof(addr->val)) == 0 &&
        peers[i].type == addr->type) {
      return true;
    }
  }
  return false;
}

static bool addr_equal(const ble_addr_t *a, const ble_addr_t *b) {
  return a && b && a->type == b->type &&
         memcmp(a->val, b->val, sizeof(a->val)) == 0;
}

static void delete_peer_bond(const ble_addr_t *addr) {
  if (!addr) {
    return;
  }
  int rc = ble_store_util_delete_peer(addr);
  if (rc != 0) {
    ESP_LOGW(TAG, "Bond delete failed: %d", rc);
  }
}

static void delete_camera_bond(const struct ble_gap_conn_desc *desc) {
  if (!desc) {
    return;
  }
  delete_peer_bond(&desc->peer_ota_addr);
  if (!addr_equal(&desc->peer_id_addr, &desc->peer_ota_addr)) {
    delete_peer_bond(&desc->peer_id_addr);
  }
}

static bool enc_failure_needs_rebond(int status) {
  return status == BLE_HS_HCI_ERR(BLE_ERR_PINKEY_MISSING) ||
         status == BLE_HS_HCI_ERR(BLE_ERR_AUTH_FAIL);
}

static void reset_camera_setup_state(void) {
  if (s_dsc_retry_initialized) {
    ble_npl_callout_stop(&s_dsc_retry_callout);
  }
  uint16_t conn_handle = s_handles.conn_handle;
  memset(&s_handles, 0, sizeof(s_handles));
  s_handles.conn_handle = conn_handle;
  s_disc_state = DISC_NONE;
  s_discovery_in_progress = false;
  s_discovery_generation++;
  s_dd21_in_progress = false;
  s_location_enabled = false;
  s_loc_enable_in_flight = false;
  s_loc_enable_generation++;
  s_dd21_retry = 0;
  s_dd21_ready = false;
  s_dd21_pending = false;
  s_notify_pending = false;
  s_remote_disc_started = false;
  s_dsc_pending_ff02 = false;
  s_dsc_in_progress = false;
  s_dsc_target = DSC_NONE;
  s_dsc_retry_count = 0;
  s_last_chr_interest = 0;
  s_ff02_cccd_deferred = false;
  s_ff02_cccd_sent = false;
  s_retried_disc_after_enc = false;
  s_last_disc_attempt_us = 0;
  s_last_dd21_attempt_us = 0;
  s_last_loc_enable_attempt_us = 0;
  publish_camera_status(true);
  schedule_camera_setup_retry();
}

static void addr_to_str(const ble_addr_t *addr, char *out, size_t len) {
  snprintf(out, len, "%02X:%02X:%02X:%02X:%02X:%02X", addr->val[5],
           addr->val[4], addr->val[3], addr->val[2], addr->val[1],
           addr->val[0]);
}

static bool str_prefix_match(const char *value, const char *prefix) {
  if (prefix == NULL || prefix[0] == '\0') {
    return true;
  }
  if (value == NULL) {
    return false;
  }
  size_t prefix_len = strlen(prefix);
  return strncasecmp(value, prefix, prefix_len) == 0;
}

static bool name_prefix_match(const struct ble_hs_adv_fields *fields,
                              const char *prefix) {
  if (prefix == NULL || prefix[0] == '\0') {
    return true;
  }
  if (fields->name == NULL || fields->name_len == 0) {
    return false;
  }
  size_t prefix_len = strlen(prefix);
  if (fields->name_len < prefix_len) {
    return false;
  }
  return strncasecmp((const char *)fields->name, prefix, prefix_len) == 0;
}

static void log_mfg_data(const uint8_t *data, uint8_t len) {
  if (!ALPHALOC_VERBOSE) {
    return;
  }
  char buf[64];
  size_t pos = 0;
  for (uint8_t i = 0; i < len && pos + 3 < sizeof(buf); ++i) {
    pos += snprintf(buf + pos, sizeof(buf) - pos, "%02X", data[i]);
  }
  buf[pos] = '\0';
  VLOGI("Sony ADV mfg_data len=%u data=%s", (unsigned)len, buf);
}

static void make_sony_uuid(uint16_t first, uint16_t second,
                           ble_uuid128_t *out) {
  uint8_t bytes[16] = {0xFF,
                       0xFF,
                       0xFF,
                       0xFF,
                       0xFF,
                       0xFF,
                       0xFF,
                       0xFF,
                       0xFF,
                       0xFF,
                       (uint8_t)(second & 0xFF),
                       (uint8_t)(second >> 8),
                       (uint8_t)(first & 0xFF),
                       (uint8_t)(first >> 8),
                       0x00,
                       0x80};
  out->u.type = BLE_UUID_TYPE_128;
  memcpy(out->value, bytes, sizeof(bytes));
}

static bool is_sony_camera_adv(const struct ble_gap_disc_desc *desc,
                               const struct ble_hs_adv_fields *fields) {
  app_config_t cfg;
  if (!config_get_snapshot(s_cfg, &cfg)) {
    cfg = *s_cfg;
    config_validate(&cfg);
  }
  if (fields->mfg_data_len < sizeof(SONY_MFG_PREFIX)) {
    return false;
  }
  uint16_t company_id =
      (uint16_t)fields->mfg_data[1] << 8 | fields->mfg_data[0];
  uint16_t product_id =
      (uint16_t)fields->mfg_data[3] << 8 | fields->mfg_data[2];
  if (company_id != 0x012D || product_id != 0x0003) {
    return false;
  }
  log_mfg_data(fields->mfg_data, fields->mfg_data_len);

  char addr_str[18];
  addr_to_str(&desc->addr, addr_str, sizeof(addr_str));

  if (!str_prefix_match(addr_str, cfg.camera_mac_prefix)) {
    VLOGI("ADV ignored: mac %s != %s", addr_str, cfg.camera_mac_prefix);
    return false;
  }

  if (cfg.camera_name_prefix[0] != '\0') {
    if (!name_prefix_match(fields, cfg.camera_name_prefix)) {
      if (fields->name == NULL || fields->name_len == 0) {
        VLOGI("ADV matched Sony camera without local name: %s", addr_str);
        return true;
      }
      VLOGI("ADV ignored: name does not match %s", cfg.camera_name_prefix);
      return false;
    }
  }

  VLOGI("ADV matched Sony camera: %s", addr_str);
  return true;
}

static int gatt_disc_chrs_cb(uint16_t conn_handle,
                             const struct ble_gatt_error *error,
                             const struct ble_gatt_chr *chr, void *arg);
static int gatt_disc_svc_cb(uint16_t conn_handle,
                            const struct ble_gatt_error *error,
                            const struct ble_gatt_svc *svc, void *arg);
static int gatt_disc_dsc_cb(uint16_t conn_handle,
                            const struct ble_gatt_error *error,
                            uint16_t chr_val_handle,
                            const struct ble_gatt_dsc *dsc, void *arg);
static int gatt_disc_all_svc_cb(uint16_t conn_handle,
                                const struct ble_gatt_error *error,
                                const struct ble_gatt_svc *svc, void *arg);
static bool uuid_matches(const ble_uuid_any_t *uuid, uint16_t first,
                         uint16_t second);
static bool uuid16_matches(const ble_uuid_any_t *uuid, uint16_t short_uuid);
static void start_all_char_discovery(uint16_t conn_handle);

static bool begin_discovery(uint16_t conn_handle, disc_state_t state) {
  if (!client_active() || conn_handle == BLE_HS_CONN_HANDLE_NONE ||
      conn_handle != s_handles.conn_handle || s_discovery_reconnect_pending ||
      s_discovery_in_progress || s_dsc_in_progress) {
    return false;
  }
  s_discovery_generation++;
  s_disc_state = state;
  s_discovery_in_progress = state != DISC_REM_DSC;
  s_dsc_in_progress = state == DISC_REM_DSC;
  return true;
}

static bool discovery_callback_current(uint16_t conn_handle, void *arg) {
  return conn_handle == s_handles.conn_handle && client_active() &&
         !s_discovery_reconnect_pending &&
         (s_discovery_in_progress || s_dsc_in_progress) &&
         (uintptr_t)arg == s_discovery_generation;
}

static void finish_discovery(void) {
  s_discovery_in_progress = false;
  s_dsc_in_progress = false;
}

static void reconnect_camera_discovery(void) {
  if (s_handles.conn_handle == BLE_HS_CONN_HANDLE_NONE) {
    return;
  }
  if (!s_discovery_reconnect_pending) {
    s_discovery_reconnect_pending = true;
    s_discovery_generation++;
    s_location_enabled = false;
    s_loc_enable_in_flight = false;
    s_loc_enable_generation++;
    publish_camera_status(true);
    if (s_dsc_retry_initialized) {
      ble_npl_callout_stop(&s_dsc_retry_callout);
    }
  }
  // Keep discovery blocked until DISCONNECT; old procedures may still be live.
  s_last_disc_attempt_us = esp_timer_get_time();
  int rc = ble_gap_terminate(s_handles.conn_handle, BLE_ERR_REM_USER_CONN_TERM);
  if (rc != 0) {
    ESP_LOGW(TAG, "Camera discovery reconnect failed: %d", rc);
  }
  schedule_camera_setup_retry();
}

static int discovery_started(int rc) {
  if (rc != 0) {
    finish_discovery();
    ESP_LOGW(TAG, "Discovery start failed: %d", rc);
  }
  return rc;
}

static void start_location_service_discovery(uint16_t conn_handle) {
  if (!begin_discovery(conn_handle, DISC_LOC_SVC)) {
    return;
  }
  ble_uuid128_t svc_uuid;
  make_sony_uuid(0xDD00, 0xDD00, &svc_uuid);
  int rc =
      ble_gattc_disc_svc_by_uuid(conn_handle, &svc_uuid.u, gatt_disc_svc_cb,
                                (void *)(uintptr_t)s_discovery_generation);
  discovery_started(rc);
}

static void start_remote_service_discovery(uint16_t conn_handle) {
  if (!begin_discovery(conn_handle, DISC_REM_SVC)) {
    return;
  }
  ble_uuid128_t svc_uuid;
  make_sony_uuid(0xFF00, 0xFF00, &svc_uuid);
  VLOGI("Starting remote service discovery");
  int rc =
      ble_gattc_disc_svc_by_uuid(conn_handle, &svc_uuid.u, gatt_disc_svc_cb,
                                (void *)(uintptr_t)s_discovery_generation);
  discovery_started(rc);
}

static int start_char_discovery(uint16_t conn_handle, uint16_t start,
                                 uint16_t end, disc_state_t state) {
  if (!begin_discovery(conn_handle, state)) {
    return 0;
  }
  return discovery_started(ble_gattc_disc_all_chrs(
      conn_handle, start, end, gatt_disc_chrs_cb,
      (void *)(uintptr_t)s_discovery_generation));
}

static void start_all_char_discovery(uint16_t conn_handle) {
  start_char_discovery(conn_handle, 1, 0xFFFF, DISC_ALL_CHR);
}

static int start_all_service_discovery(uint16_t conn_handle) {
  if (!begin_discovery(conn_handle, DISC_ALL_SVC)) {
    return 0;
  }
  return discovery_started(ble_gattc_disc_all_svcs(
      conn_handle, gatt_disc_all_svc_cb,
      (void *)(uintptr_t)s_discovery_generation));
}

static void start_dd21_read(uint16_t conn_handle) {
  if (s_dd21_in_progress || s_discovery_reconnect_pending) {
    return;
  }
  s_last_dd21_attempt_us = esp_timer_get_time();
  int rc = ble_gattc_read(conn_handle, s_handles.chr_dd21, dd21_read_cb, NULL);
  s_dd21_in_progress = (rc == 0);
  if (rc != 0) {
    ESP_LOGW(TAG, "DD21 read start failed: %d", rc);
  }
}

static int dd21_read_cb(uint16_t conn_handle,
                        const struct ble_gatt_error *error,
                        struct ble_gatt_attr *attr, void *arg) {
  (void)arg;
  if (!client_active() || conn_handle != s_handles.conn_handle ||
      s_discovery_reconnect_pending) {
    return 0;
  }
  s_dd21_in_progress = false;
  if (error->status != 0 || attr == NULL || attr->om == NULL) {
    ESP_LOGW(TAG, "DD21 read failed: %d", error->status);
    if (s_dd21_retry < 2 && s_handles.chr_dd21 != 0) {
      s_dd21_retry++;
      start_dd21_read(conn_handle);
    }
    return 0;
  }

  uint8_t buf[7] = {0};
  int rc = ble_hs_mbuf_to_flat(attr->om, buf, sizeof(buf), NULL);
  if (rc != 0) {
    ESP_LOGW(TAG, "DD21 read decode failed: %d", rc);
    return 0;
  }
  s_require_tz_dst = (buf[4] & 0x02) != 0;
  s_dd21_ready = true;
  ESP_LOGI(TAG, "DD21 flag byte=0x%02X require_tz_dst=%d", buf[4],
           s_require_tz_dst);
  enable_location_updates(conn_handle);
  return 0;
}

static void enable_notifications(uint16_t conn_handle) {
  if (s_handles.cccd_ff02 == 0) {
    ESP_LOGW(TAG, "CCCD handle not found");
    return;
  }
  if (!s_encrypted) {
    s_notify_pending = true;
    VLOGI("Deferring notifications until encryption");
    return;
  }
  s_cccd_ff02_ctx.handle = s_handles.cccd_ff02;
  s_cccd_ff02_ctx.chr_handle = s_handles.chr_ff02;
  uint8_t val_le[2] = {0x01, 0x00};
  int rc = ble_gattc_write_flat(conn_handle, s_handles.cccd_ff02, val_le,
                                sizeof(val_le), cccd_write_cb,
                                &s_cccd_ff02_ctx);
  if (rc != 0) {
    ESP_LOGW(TAG, "FF02 CCCD write start failed: %d", rc);
    return;
  }
  ESP_LOGI(TAG, "Subscribing to FF02 notifications");
  s_ff02_cccd_sent = true;
  s_notify_pending = false;
}

static int cccd_write_cb(uint16_t conn_handle,
                         const struct ble_gatt_error *error,
                         struct ble_gatt_attr *attr, void *arg) {
  (void)attr;
  if (!client_active() || conn_handle != s_handles.conn_handle) {
    return 0;
  }
  cccd_ctx_t *ctx = (cccd_ctx_t *)arg;
  const char *label = ctx ? ctx->label : "CCCD";
  if (error->status != 0) {
    s_ff02_cccd_sent = false;
    ESP_LOGW(TAG, "%s CCCD write failed: %d", label, error->status);
    return 0;
  }
  ESP_LOGI(TAG, "%s CCCD write ok", label);
  if (ctx) {
    int rc = ble_gattc_read(conn_handle, ctx->handle, cccd_read_cb, ctx);
    if (rc != 0) {
      ESP_LOGW(TAG, "%s CCCD read start failed: %d", label, rc);
    }
  }
  return 0;
}

static int cccd_read_cb(uint16_t conn_handle,
                        const struct ble_gatt_error *error,
                        struct ble_gatt_attr *attr, void *arg) {
  (void)conn_handle;
  cccd_ctx_t *ctx = (cccd_ctx_t *)arg;
  const char *label = ctx ? ctx->label : "CCCD";
  if (error->status != 0 || attr == NULL || attr->om == NULL) {
    ESP_LOGW(TAG, "%s CCCD read failed: %d", label, error->status);
    return 0;
  }
  uint8_t buf[2] = {0};
  int rc = ble_hs_mbuf_to_flat(attr->om, buf, sizeof(buf), NULL);
  if (rc != 0) {
    ESP_LOGW(TAG, "%s CCCD read decode failed: %d", label, rc);
    return 0;
  }
  uint16_t val = (uint16_t)buf[0] | ((uint16_t)buf[1] << 8);
  ESP_LOGI(TAG, "%s CCCD value=0x%04X", label, val);
  return 0;
}

static void try_start_ff02_dsc(uint16_t conn_handle) {
  if (conn_handle == BLE_HS_CONN_HANDLE_NONE ||
      conn_handle != s_handles.conn_handle) {
    return;
  }
  if (s_handles.chr_ff02 == 0 || s_handles.cccd_ff02 != 0) {
    return;
  }
  if (s_dsc_in_progress || s_discovery_in_progress ||
      s_discovery_reconnect_pending) {
    s_dsc_pending_ff02 = true;
    return;
  }
  if (!s_encrypted) {
    s_dsc_pending_ff02 = true;
    schedule_dsc_retry();
    return;
  }
  uint16_t end = s_handles.end_ff02
                     ? s_handles.end_ff02
                     : (s_handles.rem_svc_end ? s_handles.rem_svc_end : 0xFFFF);
  if (end <= s_handles.chr_ff02) {
    s_dsc_pending_ff02 = false;
    ESP_LOGW(TAG, "FF02 has no descriptor range");
    return;
  }
  if (!begin_discovery(conn_handle, DISC_REM_DSC)) {
    return;
  }
  s_dsc_target = DSC_FF02;
  int rc = ble_gattc_disc_all_dscs(conn_handle, s_handles.chr_ff02, end,
                                   gatt_disc_dsc_cb,
                                   (void *)(uintptr_t)s_discovery_generation);
  if (rc == 0) {
    s_dsc_pending_ff02 = false;
    return;
  }
  finish_discovery();
  s_dsc_target = DSC_NONE;
  s_dsc_pending_ff02 = true;
  ESP_LOGW(TAG, "Descriptor discovery start failed: %d", rc);
  schedule_dsc_retry();
}

static void try_start_pending_dsc(uint16_t conn_handle) {
  if (s_dsc_in_progress) {
    return;
  }
  if (s_dsc_pending_ff02) {
    try_start_ff02_dsc(conn_handle);
  }
}

static void dsc_retry_cb(struct ble_npl_event *event) {
  (void)event;
  if (!client_active() || s_discovery_reconnect_pending ||
      s_handles.conn_handle == BLE_HS_CONN_HANDLE_NONE ||
      !s_dsc_pending_ff02 || s_dsc_in_progress) {
    return;
  }
  if (!s_encrypted || s_discovery_in_progress) {
    schedule_dsc_retry();
    return;
  }
  if (s_dsc_retry_count >= 4) {
    s_dsc_pending_ff02 = false;
    ESP_LOGW(TAG, "FF02 descriptor discovery retries exhausted");
    return;
  }
  s_dsc_retry_count++;
  try_start_pending_dsc(s_handles.conn_handle);
}

static void schedule_dsc_retry(void) {
  if (!s_dsc_retry_initialized || !client_active() ||
      s_discovery_reconnect_pending ||
      s_handles.conn_handle == BLE_HS_CONN_HANDLE_NONE) {
    return;
  }
  int rc = ble_npl_callout_reset(&s_dsc_retry_callout,
                                ble_npl_time_ms_to_ticks32(500));
  if (rc != 0) {
    ESP_LOGW(TAG, "Descriptor retry scheduling failed: %d", rc);
  }
}

static int dd31_write_cb(uint16_t conn_handle,
                         const struct ble_gatt_error *error,
                         struct ble_gatt_attr *attr, void *arg) {
  (void)attr;
  if (!client_active() || conn_handle != s_handles.conn_handle ||
      !s_loc_enable_in_flight ||
      (uintptr_t)arg != s_loc_enable_generation) {
    return 0;
  }
  s_loc_enable_in_flight = false;
  if (error->status != 0 || !s_encrypted) {
    s_last_loc_enable_attempt_us = esp_timer_get_time();
    ESP_LOGW(TAG, "DD31 write failed: status=%d encrypted=%d", error->status,
             s_encrypted);
    return 0;
  }
  s_location_enabled = true;
  publish_camera_status(false);
  ESP_LOGI(TAG, "Location updates enabled");
  return 0;
}

static int dd30_write_cb(uint16_t conn_handle,
                         const struct ble_gatt_error *error,
                         struct ble_gatt_attr *attr, void *arg) {
  (void)attr;
  if (!client_active() || conn_handle != s_handles.conn_handle ||
      !s_loc_enable_in_flight ||
      (uintptr_t)arg != s_loc_enable_generation) {
    return 0;
  }
  if (error->status != 0 || !s_encrypted) {
    s_loc_enable_in_flight = false;
    s_last_loc_enable_attempt_us = esp_timer_get_time();
    ESP_LOGW(TAG, "DD30 write failed: status=%d encrypted=%d", error->status,
             s_encrypted);
    return 0;
  }
  uint8_t on = 0x01;
  ESP_LOGI(TAG, "Enabling location updates");
  int rc = ble_gattc_write_flat(conn_handle, s_handles.chr_dd31, &on,
                                sizeof(on), dd31_write_cb, arg);
  if (rc != 0) {
    s_loc_enable_in_flight = false;
    s_last_loc_enable_attempt_us = esp_timer_get_time();
    ESP_LOGW(TAG, "DD31 write start failed: %d", rc);
  }
  return 0;
}

static void enable_location_updates(uint16_t conn_handle) {
  if (conn_handle == BLE_HS_CONN_HANDLE_NONE ||
      conn_handle != s_handles.conn_handle || s_loc_enable_in_flight ||
      s_discovery_reconnect_pending ||
      s_location_enabled || s_discovery_in_progress || s_dsc_in_progress ||
      s_dsc_pending_ff02) {
    return;
  }
  if (s_handles.chr_dd21 != 0) {
    if (!s_encrypted) {
      s_dd21_pending = true;
      VLOGI("Deferring DD21 read until encryption");
    } else if (!s_dd21_ready) {
      s_dd21_pending = false;
      start_dd21_read(conn_handle);
    }
  }
  if (!s_encrypted || !s_dd21_ready) {
    VLOGI("Deferring DD30/DD31 writes until encrypted and DD21 read");
    return;
  }
  if (s_handles.chr_dd30 == 0 || s_handles.chr_dd31 == 0) {
    return;
  }
  s_last_loc_enable_attempt_us = esp_timer_get_time();
  s_loc_enable_in_flight = true;
  s_loc_enable_generation++;
  uint8_t on = 0x01;
  ESP_LOGI(TAG, "Unlocking location");
  int rc = ble_gattc_write_flat(
      conn_handle, s_handles.chr_dd30, &on, sizeof(on), dd30_write_cb,
      (void *)(uintptr_t)s_loc_enable_generation);
  if (rc != 0) {
    s_loc_enable_in_flight = false;
    ESP_LOGW(TAG, "DD30 write start failed: %d", rc);
  }
}

static bool location_characteristics_discovered(void) {
  return s_handles.chr_dd11 != 0 && s_handles.chr_dd21 != 0 &&
         s_handles.chr_dd30 != 0 && s_handles.chr_dd31 != 0;
}

static void retry_camera_setup(void) {
  if (s_handles.conn_handle == BLE_HS_CONN_HANDLE_NONE) {
    return;
  }

  int64_t now = esp_timer_get_time();
  if (s_discovery_reconnect_pending) {
    if (now - s_last_disc_attempt_us > 3000000) {
      reconnect_camera_discovery();
    }
    return;
  }
  if (!s_encrypted) {
    if (now - s_last_security_attempt_us <= 3000000) {
      return;
    }
    s_last_security_attempt_us = now;
    ESP_LOGI(TAG, "Retrying BLE security");
    int rc = ble_gap_security_initiate(s_handles.conn_handle);
    if (rc != 0) {
      ESP_LOGW(TAG, "Security retry start failed: %d", rc);
    }
    return;
  }

  if (s_discovery_in_progress || s_dsc_in_progress || s_dsc_pending_ff02 ||
      s_dd21_in_progress || s_loc_enable_in_flight) {
    return;
  }

  if (!location_characteristics_discovered()) {
    if (now - s_last_disc_attempt_us <= 3000000) {
      return;
    }
    reset_camera_setup_state();
    s_last_disc_attempt_us = now;
    ESP_LOGI(TAG, "Retrying camera service discovery");
    start_location_service_discovery(s_handles.conn_handle);
    return;
  }

  if (!s_dd21_ready) {
    if (now - s_last_dd21_attempt_us <= 3000000) {
      return;
    }
    ESP_LOGI(TAG, "Retrying DD21 read");
    start_dd21_read(s_handles.conn_handle);
    return;
  }

  if (!s_location_enabled && now - s_last_loc_enable_attempt_us > 3000000) {
    s_last_loc_enable_attempt_us = now;
    ESP_LOGI(TAG, "Retrying location enable");
    enable_location_updates(s_handles.conn_handle);
  }
}

static void schedule_camera_setup_retry(void) {
  if (!s_setup_retry_initialized || !client_active() ||
      s_handles.conn_handle == BLE_HS_CONN_HANDLE_NONE) {
    return;
  }
  int rc = ble_npl_callout_reset(&s_setup_retry_callout,
                                ble_npl_time_ms_to_ticks32(1000));
  if (rc != 0) {
    ESP_LOGW(TAG, "Camera setup retry scheduling failed: %d", rc);
  }
}

static void camera_setup_retry_cb(struct ble_npl_event *event) {
  (void)event;
  if (!client_active()) {
    return;
  }
  retry_camera_setup();
  if (s_encrypted && s_location_enabled && s_dd21_ready &&
      location_characteristics_discovered() && !s_discovery_in_progress &&
      !s_dsc_in_progress && !s_dsc_pending_ff02) {
    return;
  }
  schedule_camera_setup_retry();
}

static int gatt_disc_svc_cb(uint16_t conn_handle,
                            const struct ble_gatt_error *error,
                            const struct ble_gatt_svc *svc, void *arg) {
  if (!discovery_callback_current(conn_handle, arg)) {
    return 0;
  }
  if (error->status == BLE_HS_ETIMEOUT) {
    ESP_LOGW(TAG, "Service discovery timed out; reconnecting");
    reconnect_camera_discovery();
    return 0;
  }
  if (error->status != 0) {
    finish_discovery();
  }
  if (error->status == 0 && svc != NULL) {
    if (s_disc_state == DISC_LOC_SVC) {
      if (s_handles.loc_svc_start == 0) {
        s_handles.loc_svc_start = svc->start_handle;
        s_handles.loc_svc_end = svc->end_handle;
        VLOGI("Location service found: start=%u end=%u", svc->start_handle,
              svc->end_handle);
      }
    } else if (s_disc_state == DISC_REM_SVC) {
      if (s_handles.rem_svc_start == 0) {
        s_handles.rem_svc_start = svc->start_handle;
        s_handles.rem_svc_end = svc->end_handle;
        VLOGI("Remote service found: start=%u end=%u", svc->start_handle,
              svc->end_handle);
      }
    }
    return 0;
  }

  if (error->status == BLE_HS_EDONE) {
    if (s_disc_state == DISC_LOC_SVC && s_handles.loc_svc_start != 0) {
      return start_char_discovery(
          conn_handle, s_handles.loc_svc_start, s_handles.loc_svc_end,
          DISC_LOC_CHR);
    }
    if (s_disc_state == DISC_LOC_SVC && s_handles.loc_svc_start == 0) {
      VLOGI("Location service not found by UUID, falling back to all services");
      return start_all_service_discovery(conn_handle);
    }
    if (s_disc_state == DISC_REM_SVC && s_handles.rem_svc_start != 0) {
      return start_char_discovery(
          conn_handle, s_handles.rem_svc_start, s_handles.rem_svc_end,
          DISC_REM_CHR);
    }
    if (s_disc_state == DISC_REM_SVC && s_handles.rem_svc_start == 0) {
      VLOGI("Remote service not found by UUID, falling back to all services");
      return start_all_service_discovery(conn_handle);
    }
  }
  if (error->status != BLE_HS_EDONE) {
    if (s_disc_state == DISC_LOC_SVC && s_handles.loc_svc_start != 0) {
      ESP_LOGW(TAG, "Location service discovery ended with %d; continuing",
               error->status);
      return start_char_discovery(
          conn_handle, s_handles.loc_svc_start, s_handles.loc_svc_end,
          DISC_LOC_CHR);
    }
    if (s_disc_state == DISC_REM_SVC && s_handles.rem_svc_start != 0) {
      ESP_LOGW(TAG, "Remote service discovery ended with %d; continuing",
               error->status);
      return start_char_discovery(
          conn_handle, s_handles.rem_svc_start, s_handles.rem_svc_end,
          DISC_REM_CHR);
    }
    if (s_disc_state == DISC_LOC_SVC) {
      ESP_LOGW(TAG,
               "Location service discovery failed with %d; scanning all services",
               error->status);
      return start_all_service_discovery(conn_handle);
    }
    if (s_disc_state == DISC_REM_SVC) {
      ESP_LOGW(TAG,
               "Remote service discovery failed with %d; scanning all services",
               error->status);
      return start_all_service_discovery(conn_handle);
    }
    VLOGW("Service discovery error=%d state=%d", error->status, s_disc_state);
  }
  return error->status;
}

static int gatt_disc_all_svc_cb(uint16_t conn_handle,
                                const struct ble_gatt_error *error,
                                const struct ble_gatt_svc *svc, void *arg) {
  if (!discovery_callback_current(conn_handle, arg)) {
    return 0;
  }
  if (error->status == BLE_HS_ETIMEOUT) {
    ESP_LOGW(TAG, "Full service discovery timed out; reconnecting");
    reconnect_camera_discovery();
    return 0;
  }
  if (error->status != 0) {
    finish_discovery();
  }
  if (error->status == 0 && svc != NULL) {
    if ((uuid_matches(&svc->uuid, 0xDD00, 0xDD00) ||
         uuid16_matches(&svc->uuid, 0xDD00)) &&
        s_handles.loc_svc_start == 0) {
      s_handles.loc_svc_start = svc->start_handle;
      s_handles.loc_svc_end = svc->end_handle;
      VLOGI("Location service found in all-svc: start=%u end=%u",
            svc->start_handle, svc->end_handle);
    } else if ((uuid_matches(&svc->uuid, 0xFF00, 0xFF00) ||
                uuid16_matches(&svc->uuid, 0xFF00)) &&
               s_handles.rem_svc_start == 0) {
      s_handles.rem_svc_start = svc->start_handle;
      s_handles.rem_svc_end = svc->end_handle;
      VLOGI("Remote service found in all-svc: start=%u end=%u",
            svc->start_handle, svc->end_handle);
    }
    return 0;
  }

  if (error->status == BLE_HS_EDONE) {
    if (s_handles.loc_svc_start != 0 && s_handles.chr_dd11 == 0) {
      return start_char_discovery(
          conn_handle, s_handles.loc_svc_start, s_handles.loc_svc_end,
          DISC_LOC_CHR);
    }
    if (s_handles.rem_svc_start != 0) {
      return start_char_discovery(
          conn_handle, s_handles.rem_svc_start, s_handles.rem_svc_end,
          DISC_REM_CHR);
    }
    ESP_LOGW(TAG,
             "Sony services not found in all-svc scan; scanning all characteristics");
    start_all_char_discovery(conn_handle);
    return 0;
  }
  return error->status;
}

static bool uuid_matches(const ble_uuid_any_t *uuid, uint16_t first,
                         uint16_t second) {
  ble_uuid128_t target;
  make_sony_uuid(first, second, &target);
  return ble_uuid_cmp(&uuid->u, &target.u) == 0;
}

static bool uuid16_matches(const ble_uuid_any_t *uuid, uint16_t short_uuid) {
  return uuid->u.type == BLE_UUID_TYPE_16 && uuid->u16.value == short_uuid;
}

static int gatt_disc_chrs_cb(uint16_t conn_handle,
                             const struct ble_gatt_error *error,
                             const struct ble_gatt_chr *chr, void *arg) {
  if (!discovery_callback_current(conn_handle, arg)) {
    return 0;
  }
  if (error->status == BLE_HS_ETIMEOUT) {
    ESP_LOGW(TAG, "Characteristic discovery timed out; reconnecting");
    reconnect_camera_discovery();
    return 0;
  }
  if (error->status != 0) {
    finish_discovery();
  }
  if (error->status == 0 && chr != NULL) {
    if (s_last_chr_interest == 1 && s_handles.end_ff02 == 0 &&
        chr->def_handle > 0) {
      s_handles.end_ff02 = (uint16_t)(chr->def_handle - 1);
      s_last_chr_interest = 0;
    }
    if (s_disc_state == DISC_LOC_CHR || s_disc_state == DISC_ALL_CHR) {
      if (uuid_matches(&chr->uuid, 0xDD11, 0xDD00) ||
          uuid16_matches(&chr->uuid, 0xDD11)) {
        s_handles.chr_dd11 = chr->val_handle;
        VLOGI("Found DD11 handle=%u", chr->val_handle);
      } else if (uuid_matches(&chr->uuid, 0xDD21, 0xDD00) ||
                 uuid16_matches(&chr->uuid, 0xDD21)) {
        s_handles.chr_dd21 = chr->val_handle;
        VLOGI("Found DD21 handle=%u", chr->val_handle);
      } else if (uuid_matches(&chr->uuid, 0xDD30, 0xDD00) ||
                 uuid16_matches(&chr->uuid, 0xDD30)) {
        s_handles.chr_dd30 = chr->val_handle;
        VLOGI("Found DD30 handle=%u", chr->val_handle);
      } else if (uuid_matches(&chr->uuid, 0xDD31, 0xDD00) ||
                 uuid16_matches(&chr->uuid, 0xDD31)) {
        s_handles.chr_dd31 = chr->val_handle;
        VLOGI("Found DD31 handle=%u", chr->val_handle);
      }
    } else if (s_disc_state == DISC_REM_CHR) {
      if (uuid_matches(&chr->uuid, 0xFF02, 0xFF00) ||
          uuid16_matches(&chr->uuid, 0xFF02)) {
        s_handles.chr_ff02 = chr->val_handle;
        VLOGI("Found FF02 handle=%u props=0x%02X (remote svc)", chr->val_handle,
              chr->properties);
        s_last_chr_interest = 1;
      }
    }
    return 0;
  }

  if (error->status == BLE_HS_EDONE) {
    if (s_last_chr_interest == 1 && s_handles.end_ff02 == 0) {
      s_handles.end_ff02 =
          s_handles.rem_svc_end ? s_handles.rem_svc_end : 0xFFFF;
    }
    s_last_chr_interest = 0;
    if (s_disc_state == DISC_LOC_CHR) {
      if (s_handles.chr_dd11 == 0) {
        VLOGI("DD11 not found in service range, scanning all characteristics");
        start_all_char_discovery(conn_handle);
        return 0;
      }
      if (s_handles.rem_svc_start != 0) {
        return start_char_discovery(
            conn_handle, s_handles.rem_svc_start, s_handles.rem_svc_end,
            DISC_REM_CHR);
      }
      if (!s_remote_disc_started) {
        s_remote_disc_started = true;
        start_remote_service_discovery(conn_handle);
      }
      return 0;
    }
    if (s_disc_state == DISC_ALL_CHR) {
      if (s_handles.chr_dd11 == 0) {
        ESP_LOGW(TAG, "DD11 not found in full characteristic scan");
      }
      if (s_handles.rem_svc_start != 0) {
        return start_char_discovery(
            conn_handle, s_handles.rem_svc_start, s_handles.rem_svc_end,
            DISC_REM_CHR);
      }
      if (!s_remote_disc_started) {
        s_remote_disc_started = true;
        start_remote_service_discovery(conn_handle);
      }
      return 0;
    }
    if (s_disc_state == DISC_REM_CHR) {
      if (s_handles.chr_ff02 != 0) {
        try_start_ff02_dsc(conn_handle);
        return 0;
      }
      ESP_LOGW(TAG, "FF02 not found in remote service");
    }
  }
  if (error->status != BLE_HS_EDONE) {
    VLOGW("Characteristic discovery error=%d state=%d", error->status,
          s_disc_state);
  }
  return error->status;
}

static int gatt_disc_dsc_cb(uint16_t conn_handle,
                            const struct ble_gatt_error *error,
                            uint16_t chr_val_handle,
                            const struct ble_gatt_dsc *dsc, void *arg) {
  if (!discovery_callback_current(conn_handle, arg) ||
      chr_val_handle != s_handles.chr_ff02 ||
      s_dsc_target != DSC_FF02 || !s_dsc_in_progress) {
    return 0;
  }
  if (error->status == BLE_HS_ETIMEOUT) {
    ESP_LOGW(TAG, "FF02 descriptor discovery timed out; reconnecting");
    reconnect_camera_discovery();
    return 0;
  }
  if (error->status == 0 && dsc != NULL) {
    if (dsc->uuid.u.type == BLE_UUID_TYPE_16 &&
        dsc->uuid.u16.value == BLE_GATT_DSC_CLT_CFG_UUID16) {
      if (chr_val_handle == s_handles.chr_ff02) {
        s_handles.cccd_ff02 = dsc->handle;
        VLOGI("Found FF02 CCCD handle=%u", dsc->handle);
      }
    }
    return 0;
  }

  if (error->status == BLE_HS_EDONE) {
    finish_discovery();
    s_dsc_target = DSC_NONE;
    s_dsc_pending_ff02 = false;
    s_ff02_cccd_deferred = s_handles.cccd_ff02 != 0;
    if (!s_ff02_cccd_deferred) {
      ESP_LOGW(TAG, "FF02 CCCD not found; notifications unavailable");
    }
  } else if (error->status != 0) {
    ESP_LOGW(TAG, "FF02 descriptor discovery failed: %d", error->status);
    finish_discovery();
    s_dsc_target = DSC_NONE;
    s_handles.cccd_ff02 = 0;
    s_dsc_pending_ff02 = true;
    schedule_dsc_retry();
  }
  return error->status;
}

static bool build_location_payload(const gps_fix_t *fix, bool require_tz_dst,
                                   int16_t tz_off_min, int16_t dst_off_min,
                                   uint8_t *out, size_t *out_len) {
  if (!fix || !fix->valid || fix->year == 0) {
    return false;
  }

  const bool send_tz_dst =
      require_tz_dst || (tz_off_min != 0 || dst_off_min != 0);
  const size_t total_len = send_tz_dst ? 95 : 91;

  int32_t lat_scaled = (int32_t)llround(fix->lat_deg * 1e7);
  int32_t lon_scaled = (int32_t)llround(fix->lon_deg * 1e7);

  out[0] = (uint8_t)((send_tz_dst ? 0x5D : 0x59) >> 8);
  out[1] = (uint8_t)((send_tz_dst ? 0x5D : 0x59) & 0xFF);

  out[2] = 0x08;
  out[3] = 0x02;
  out[4] = 0xFC;
  out[5] = send_tz_dst ? 0x03 : 0x00;
  out[6] = 0x00;
  out[7] = 0x00;
  out[8] = 0x10;
  out[9] = 0x10;
  out[10] = 0x10;

  out[11] = (uint8_t)((uint32_t)lat_scaled >> 24);
  out[12] = (uint8_t)((uint32_t)lat_scaled >> 16);
  out[13] = (uint8_t)((uint32_t)lat_scaled >> 8);
  out[14] = (uint8_t)((uint32_t)lat_scaled);
  out[15] = (uint8_t)((uint32_t)lon_scaled >> 24);
  out[16] = (uint8_t)((uint32_t)lon_scaled >> 16);
  out[17] = (uint8_t)((uint32_t)lon_scaled >> 8);
  out[18] = (uint8_t)((uint32_t)lon_scaled);

  out[19] = (uint8_t)(fix->year >> 8);
  out[20] = (uint8_t)(fix->year & 0xFF);
  out[21] = fix->month;
  out[22] = fix->day;
  out[23] = fix->hour;
  out[24] = fix->minute;
  out[25] = fix->second;

  memset(out + 26, 0, (send_tz_dst ? 95 : 91) - 26);

  if (send_tz_dst) {
    uint16_t tz = (uint16_t)tz_off_min;
    uint16_t dst = (uint16_t)dst_off_min;
    out[91] = (uint8_t)(tz >> 8);
    out[92] = (uint8_t)(tz & 0xFF);
    out[93] = (uint8_t)(dst >> 8);
    out[94] = (uint8_t)(dst & 0xFF);
  }

  *out_len = total_len;
  return true;
}

static bool send_location_on_host(const gps_fix_t *fix) {
  if (!client_active() || !s_encrypted || s_discovery_reconnect_pending) {
    return false;
  }
  if (s_handles.conn_handle == BLE_HS_CONN_HANDLE_NONE) {
    VLOGW("Skip location send: no connection");
    return false;
  }
  if (!s_location_enabled) {
    VLOGW("Skip location send: location updates not enabled");
    return false;
  }
  if (s_handles.chr_dd21 != 0 && !s_dd21_ready) {
    VLOGW("Skip location send: DD21 not ready");
    return false;
  }
  if (s_handles.chr_dd11 == 0) {
    VLOGW("Skip location send: DD11 not discovered");
    return false;
  }
  app_config_t cfg;
  int16_t tz_off_min = s_tz_off_min;
  int16_t dst_off_min = s_dst_off_min;
  config_set_defaults(&cfg);
  if (s_cfg) {
    if (!config_get_snapshot(s_cfg, &cfg)) {
      ESP_LOGW(TAG, "Location send skipped: configuration unavailable");
      return false;
    }
    tz_off_min = cfg.tz_offset_min;
    dst_off_min = cfg.dst_offset_min;
  }
  // A fix may expire while waiting for the host queue to drain.
  int64_t age_us = esp_timer_get_time() - fix->last_fix_time_us;
  if (age_us < 0 || age_us > (int64_t)cfg.max_gps_age_s * 1000000LL) {
    VLOGW("Skip location send: GPS fix expired");
    return false;
  }
  uint8_t payload[95];
  size_t payload_len = 0;
  if (!build_location_payload(fix, s_require_tz_dst, tz_off_min, dst_off_min,
                              payload, &payload_len)) {
    ESP_LOGW(TAG, "Location payload unavailable");
    return false;
  }
  uint16_t mtu = ble_att_mtu(s_handles.conn_handle);
  uint16_t max_payload = mtu > 3 ? (uint16_t)(mtu - 3) : 0;
  int rc = 0;
  if (!client_active()) {
    return false;
  }
  if (payload_len > max_payload) {
    struct os_mbuf *om = ble_hs_mbuf_from_flat(payload, (uint16_t)payload_len);
    if (om == NULL) {
      ESP_LOGW(TAG, "Location write failed: no mbuf");
      return false;
    }
    rc = ble_gattc_write_long(s_handles.conn_handle, s_handles.chr_dd11, 0, om,
                              NULL, NULL);
  } else {
    rc = ble_gattc_write_flat(s_handles.conn_handle, s_handles.chr_dd11,
                              payload, payload_len, NULL, NULL);
  }
#if ALPHALOC_VERBOSE
  if (!s_payload_logged) {
    s_payload_logged = true;
    ESP_LOGI(TAG, "Location payload (%u bytes):", (unsigned)payload_len);
    ESP_LOG_BUFFER_HEX(TAG, payload, payload_len);
  }
#endif
  VLOGI("Location write %s (%u bytes)", rc == 0 ? "ok" : "failed",
        (unsigned)payload_len);
  if (rc != 0) {
    ESP_LOGW(TAG, "Location write start failed: %d", rc);
  }
  if (rc == 0 && s_ff02_cccd_deferred && !s_ff02_cccd_sent && s_encrypted &&
      s_handles.cccd_ff02 != 0) {
    ESP_LOGI(TAG, "Enabling FF02 notifications after first location write");
    enable_notifications(s_handles.conn_handle);
  }
  return rc == 0;
}

static void location_send_cb(struct ble_npl_event *event) {
  (void)event;
  gps_fix_t fix;
  portENTER_CRITICAL(&s_client_lock);
  bool pending = s_client.active && s_client.ready && s_client.pending;
  if (pending) {
    fix = s_client.fix;
  }
  s_client.pending = false;
  s_client.wakeup_pending = false;
  portEXIT_CRITICAL(&s_client_lock);
  if (pending) {
    send_location_on_host(&fix);
  }
}

bool ble_client_send_location(const gps_fix_t *fix) {
  if (!fix || !fix->valid) {
    return false;
  }
  portENTER_CRITICAL(&s_client_lock);
  if (!s_client.ready) {
    portEXIT_CRITICAL(&s_client_lock);
    return false;
  }
  // One owned copy: newer updates replace a fix still waiting for dispatch.
  s_client.fix = *fix;
  s_client.pending = true;
  bool wakeup = !s_client.wakeup_pending;
  s_client.wakeup_pending = true;
  portEXIT_CRITICAL(&s_client_lock);
  if (wakeup) {
    // The timer posts a persistent event to the host queue. Direct queue put
    // can block a host-task producer (the focus callback) if that queue is full.
    int rc = ble_npl_callout_reset(&s_location_callout,
                                  ble_npl_time_ms_to_ticks32(1));
    if (rc != 0) {
      portENTER_CRITICAL(&s_client_lock);
      s_client.pending = false;
      s_client.wakeup_pending = false;
      portEXIT_CRITICAL(&s_client_lock);
      ESP_LOGW(TAG, "Location send scheduling failed: %d", rc);
      return false;
    }
  }
  return true;
}

bool ble_client_is_connected(void) {
  portENTER_CRITICAL(&s_client_lock);
  bool connected = s_client.connected;
  portEXIT_CRITICAL(&s_client_lock);
  return connected;
}

bool ble_client_is_bonded(void) {
  portENTER_CRITICAL(&s_client_lock);
  bool bonded = s_client.bonded;
  portEXIT_CRITICAL(&s_client_lock);
  return bonded;
}

int ble_client_gap_event_cb(struct ble_gap_event *event, void *arg) {
  if (!client_active()) {
    return 0;
  }
  switch (event->type) {
  case BLE_GAP_EVENT_DISC: {
    struct ble_hs_adv_fields fields;
    if (ble_hs_adv_parse_fields(&fields, event->disc.data,
                                event->disc.length_data) != 0) {
      return 0;
    }
    if (!is_sony_camera_adv(&event->disc, &fields)) {
      return 0;
    }
    int rc = ble_gap_disc_cancel();
    if (rc != 0) {
      VLOGW("Scan cancel failed: %d", rc);
    }
    s_connecting_camera = true;
    rc = ble_gap_connect(s_own_addr_type, &event->disc.addr, 30000, NULL,
                         ble_client_gap_event_cb, NULL);
    if (rc != 0) {
      ESP_LOGW(TAG, "Connect start failed: %d", rc);
      s_connecting_camera = false;
      ble_start_scan();
      return 0;
    }
    VLOGI("Connecting to Sony camera");
    return 0;
  }
  case BLE_GAP_EVENT_CONNECT: {
    if (event->connect.status == 0) {
      if (s_connecting_camera) {
        s_handles.conn_handle = event->connect.conn_handle;
        publish_camera_status(true);
        ESP_LOGI(TAG, "Connected to camera");
        struct ble_gap_conn_desc desc;
        if (ble_gap_conn_find(s_handles.conn_handle, &desc) == 0 &&
            peer_is_bonded(&desc.peer_ota_addr)) {
          ESP_LOGI(TAG, "Existing bond found; skipping pairing");
        }
        VLOGI("Start security");
        s_last_security_attempt_us = esp_timer_get_time();
        int rc = ble_gap_security_initiate(s_handles.conn_handle);
        if (rc != 0) {
          ESP_LOGW(TAG, "Security start failed: %d", rc);
        }
        s_connecting_camera = false;
        schedule_camera_setup_retry();
      } else {
        ESP_LOGI(TAG, "Config client connected");
      }
    } else {
      ESP_LOGW(TAG, "Connect failed: %d", event->connect.status);
      s_connecting_camera = false;
      ble_start_scan();
    }
    return 0;
  }
  case BLE_GAP_EVENT_DISCONNECT: {
    if (event->disconnect.conn.conn_handle == s_handles.conn_handle) {
      ESP_LOGI(TAG, "Camera disconnected");
      if (s_dsc_retry_initialized) {
        ble_npl_callout_stop(&s_dsc_retry_callout);
      }
      memset(&s_handles, 0, sizeof(s_handles));
      s_handles.conn_handle = BLE_HS_CONN_HANDLE_NONE;
      s_disc_state = DISC_NONE;
      s_discovery_in_progress = false;
      s_discovery_generation++;
      s_discovery_reconnect_pending = false;
      s_dd21_in_progress = false;
      if (s_setup_retry_initialized) {
        ble_npl_callout_stop(&s_setup_retry_callout);
      }
      s_connecting_camera = false;
      s_location_enabled = false;
      s_loc_enable_in_flight = false;
      s_loc_enable_generation++;
      s_dd21_retry = 0;
      s_dd21_ready = false;
      s_dd21_pending = false;
      s_encrypted = false;
      s_notify_pending = false;
      s_remote_disc_started = false;
      s_dsc_pending_ff02 = false;
      s_dsc_in_progress = false;
      s_dsc_target = DSC_NONE;
      s_dsc_retry_count = 0;
      s_last_chr_interest = 0;
      s_last_security_attempt_us = 0;
      s_last_disc_attempt_us = 0;
      s_ff02_cccd_deferred = false;
      s_ff02_cccd_sent = false;
      s_bonded_camera = false;
      s_rebond_attempted = false;
      s_retried_disc_after_enc = false;
      publish_camera_status(true);
      ble_start_scan();
    } else {
      ESP_LOGI(TAG, "Config client disconnected");
    }
    return 0;
  }
  case BLE_GAP_EVENT_NOTIFY_RX: {
    if (event->notify_rx.conn_handle != s_handles.conn_handle) {
      return 0;
    }
#if ALPHALOC_VERBOSE
    ESP_LOGI(TAG, "Notify rx handle=%u len=%u", event->notify_rx.attr_handle,
             (unsigned)event->notify_rx.om->om_len);
    ESP_LOG_BUFFER_HEX(TAG, event->notify_rx.om->om_data,
                       event->notify_rx.om->om_len);
#endif
    if (event->notify_rx.attr_handle == 3 && event->notify_rx.om->om_len == 4 &&
        event->notify_rx.om->om_data[0] == 0x01 &&
        event->notify_rx.om->om_data[1] == 0x00 &&
        event->notify_rx.om->om_data[2] == 0xFF &&
        event->notify_rx.om->om_data[3] == 0xFF) {
      ESP_LOGW(TAG, "Camera reported GATT service change");
      if (!s_discovery_reconnect_pending) {
        reconnect_camera_discovery();
      }
      return 0;
    }
    if (event->notify_rx.attr_handle == s_handles.chr_ff02) {
      uint8_t focus_msg[] = {0x02, 0x3F, 0x20};
      if (event->notify_rx.om->om_len == sizeof(focus_msg) &&
          memcmp(event->notify_rx.om->om_data, focus_msg, sizeof(focus_msg)) ==
              0) {
        ESP_LOGI(TAG, "Focus acquired notification");
        portENTER_CRITICAL(&s_client_lock);
        ble_focus_cb_t cb = s_focus_cb;
        void *ctx = s_focus_ctx;
        portEXIT_CRITICAL(&s_client_lock);
        if (cb) {
          cb(ctx);
        }
      }
    }
    return 0;
  }
  case BLE_GAP_EVENT_PASSKEY_ACTION: {
    struct ble_sm_io pkey = {0};
    pkey.action = event->passkey.params.action;
    if (pkey.action == BLE_SM_IOACT_DISP || pkey.action == BLE_SM_IOACT_INPUT) {
      app_config_t cfg;
      pkey.passkey = 0;
      if (config_get_snapshot(s_cfg, &cfg)) {
        pkey.passkey = cfg.ble_passkey;
      }
      ble_sm_inject_io(event->passkey.conn_handle, &pkey);
      ESP_LOGI(TAG, "Passkey used for pairing");
    }
    return 0;
  }
  case BLE_GAP_EVENT_REPEAT_PAIRING: {
    struct ble_gap_conn_desc desc;
    if (ble_gap_conn_find(event->repeat_pairing.conn_handle, &desc) == 0) {
      delete_camera_bond(&desc);
      ESP_LOGW(TAG, "Repeat pairing requested; deleted existing bond");
    }
    return BLE_GAP_REPEAT_PAIRING_RETRY;
  }
  case BLE_GAP_EVENT_ENC_CHANGE:
    if (event->enc_change.conn_handle != s_handles.conn_handle ||
        s_discovery_reconnect_pending) {
      return 0;
    }
    s_encrypted = (event->enc_change.status == 0);
    if (!s_encrypted) {
      ESP_LOGW(TAG, "Encryption failed: %d", event->enc_change.status);
      schedule_camera_setup_retry();
    }
    if (!s_encrypted && !s_rebond_attempted &&
        enc_failure_needs_rebond(event->enc_change.status)) {
      struct ble_gap_conn_desc desc;
      int rc = ble_gap_conn_find(event->enc_change.conn_handle, &desc);
      if (rc == 0) {
        // Avoid repeated bond deletion and immediate pairing loops.
        s_rebond_attempted = true;
        delete_camera_bond(&desc);
        ESP_LOGW(TAG, "Retrying pairing after missing or invalid camera key");
        s_last_security_attempt_us = esp_timer_get_time();
        rc = ble_gap_security_initiate(event->enc_change.conn_handle);
        if (rc != 0) {
          ESP_LOGW(TAG, "Security retry start failed: %d", rc);
        }
      } else {
        ESP_LOGW(TAG, "Camera connection lookup failed: %d", rc);
      }
    }
    if (s_encrypted) {
      struct ble_gap_conn_desc desc;
      if (ble_gap_conn_find(event->enc_change.conn_handle, &desc) == 0) {
        s_bonded_camera = desc.sec_state.bonded;
      } else {
        s_bonded_camera = false;
      }
      if (!s_retried_disc_after_enc && s_disc_state == DISC_NONE &&
          s_handles.loc_svc_start == 0 && s_handles.rem_svc_start == 0) {
        s_retried_disc_after_enc = true;
        s_disc_state = DISC_NONE;
        s_remote_disc_started = false;
        s_last_disc_attempt_us = esp_timer_get_time();
        start_location_service_discovery(s_handles.conn_handle);
      }
    } else {
      s_bonded_camera = false;
    }
    publish_camera_status(!s_encrypted);
    ESP_LOGI(TAG, "Encryption %s", s_encrypted ? "enabled" : "failed");
    if (s_encrypted && s_dd21_pending && s_handles.chr_dd21 != 0 &&
        !s_dd21_ready) {
      s_dd21_pending = false;
      start_dd21_read(s_handles.conn_handle);
    }
    if (s_encrypted && s_notify_pending && s_handles.cccd_ff02 != 0) {
      enable_notifications(s_handles.conn_handle);
    }
    return 0;
  default:
    return 0;
  }
}

static void ble_start_scan(void) {
  struct ble_gap_disc_params params = {0};
  params.passive = 0;
  // NimBLE uses 0.625 ms units. Keep scanning until a camera is found, with
  // a 60% receive duty cycle while searching.
  params.itvl = 0x0050;   // 50 ms scan interval
  params.window = 0x0030; // 30 ms scan window
  params.filter_duplicates = 1;
  int rc = ble_gap_disc(s_own_addr_type, BLE_HS_FOREVER, &params,
                        ble_client_gap_event_cb, NULL);
  if (rc != 0) {
    ESP_LOGW(TAG, "BLE scan start failed: %d", rc);
    return;
  }
  ESP_LOGI(TAG, "BLE scanning");
}

static void ble_on_sync(void) {
  int rc = ble_hs_id_infer_auto(0, &s_own_addr_type);
  if (rc != 0) {
    ESP_LOGW(TAG, "Address type infer failed: %d", rc);
    return;
  }
  ble_start_scan();
#if ALPHALOC_BLE_CONFIG
  ble_config_server_on_sync();
#endif
}

static void ble_host_task(void *param) {
  nimble_port_run();
  nimble_port_freertos_deinit();
}

void ble_client_init(const app_config_t *cfg) {
  s_cfg = cfg;
  memset(&s_handles, 0, sizeof(s_handles));
  s_bonded_camera = false;
  s_rebond_attempted = false;
  s_handles.conn_handle = BLE_HS_CONN_HANDLE_NONE;
  s_disc_state = DISC_NONE;
  s_discovery_in_progress = false;
  s_discovery_generation++;
  s_discovery_reconnect_pending = false;
  s_dd21_in_progress = false;
  s_require_tz_dst = false;
  s_tz_off_min = cfg ? cfg->tz_offset_min : 0;
  s_dst_off_min = cfg ? cfg->dst_offset_min : 0;
  s_connecting_camera = false;
  s_dd21_retry = 0;
  s_location_enabled = false;
  s_loc_enable_in_flight = false;
  s_loc_enable_generation++;
  s_dd21_ready = false;
  s_dd21_pending = false;
  s_encrypted = false;
  s_notify_pending = false;
  s_remote_disc_started = false;
  s_dsc_pending_ff02 = false;
  s_dsc_in_progress = false;
  s_last_loc_enable_attempt_us = 0;
  s_last_dd21_attempt_us = 0;
  s_dsc_target = DSC_NONE;
  s_dsc_retry_count = 0;
  s_last_chr_interest = 0;
  s_last_security_attempt_us = 0;
  s_last_disc_attempt_us = 0;
  s_ff02_cccd_deferred = false;
  s_ff02_cccd_sent = false;
  s_retried_disc_after_enc = false;
#if ALPHALOC_VERBOSE
  s_payload_logged = false;
#endif

  nimble_port_init();
  if (!s_location_callout_initialized) {
    int rc = ble_npl_callout_init(&s_location_callout,
                                 nimble_port_get_dflt_eventq(),
                                 location_send_cb, NULL);
    if (rc == 0) {
      s_location_callout_initialized = true;
    } else {
      ESP_LOGE(TAG, "Location send initialization failed: %d", rc);
    }
  }
  if (!s_setup_retry_initialized) {
    int rc = ble_npl_callout_init(&s_setup_retry_callout,
                                 nimble_port_get_dflt_eventq(),
                                 camera_setup_retry_cb, NULL);
    if (rc == 0) {
      s_setup_retry_initialized = true;
    } else {
      ESP_LOGE(TAG, "Camera setup retry initialization failed: %d", rc);
    }
  }
  portENTER_CRITICAL(&s_client_lock);
  s_client.active = true;
  s_client.pending = false;
  s_client.wakeup_pending = false;
  portEXIT_CRITICAL(&s_client_lock);
  publish_camera_status(true);
  ble_svc_gap_init();
  ble_svc_gatt_init();
  ble_store_config_init();
#if ALPHALOC_BLE_CONFIG
  ble_config_server_register((app_config_t *)cfg);
#endif

  ble_svc_gap_device_name_set("AlphaLoc");

  ble_hs_cfg.sync_cb = ble_on_sync;
  ble_hs_cfg.reset_cb = NULL;
  ble_hs_cfg.sm_bonding = 1;
  ble_hs_cfg.sm_io_cap = BLE_HS_IO_NO_INPUT_OUTPUT;
  ble_hs_cfg.sm_mitm = 0;
  ble_hs_cfg.sm_sc = 1;
  ble_hs_cfg.sm_our_key_dist =
      BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
  ble_hs_cfg.sm_their_key_dist =
      BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;

  if (!s_dsc_retry_initialized) {
    int rc = ble_npl_callout_init(&s_dsc_retry_callout,
                                 nimble_port_get_dflt_eventq(),
                                 dsc_retry_cb, NULL);
    if (rc == 0) {
      s_dsc_retry_initialized = true;
    } else {
      ESP_LOGW(TAG, "Descriptor retry initialization failed: %d", rc);
    }
  }

  nimble_port_freertos_init(ble_host_task);
}

void ble_client_set_focus_callback(ble_focus_cb_t cb, void *ctx) {
  portENTER_CRITICAL(&s_client_lock);
  s_focus_cb = cb;
  s_focus_ctx = ctx;
  portEXIT_CRITICAL(&s_client_lock);
}

void ble_client_deinit(void) {
  portENTER_CRITICAL(&s_client_lock);
  s_client.active = false;
  s_client.connected = false;
  s_client.bonded = false;
  s_client.ready = false;
  s_client.pending = false;
  portEXIT_CRITICAL(&s_client_lock);
  // Keep the callout allocated while the NimBLE host and its queue are alive.
  if (s_location_callout_initialized) {
    ble_npl_callout_stop(&s_location_callout);
  }
  if (s_setup_retry_initialized) {
    ble_npl_callout_stop(&s_setup_retry_callout);
  }
  if (s_dsc_retry_initialized) {
    ble_npl_callout_stop(&s_dsc_retry_callout);
  }
}
