#include "battery.h"

#include <string.h>

#ifndef ALPHALOC_BATTERY_MONITOR
#define ALPHALOC_BATTERY_MONITOR 0
#endif
#ifndef ALPHALOC_VERBOSE
#define ALPHALOC_VERBOSE 0
#endif

#if ALPHALOC_BATTERY_MONITOR

#include "driver/gpio.h"
#include "driver/i2c.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

static const char *TAG = "battery";

static battery_status_t s_status;
static bool s_inited = false;
static bool s_lc709203f_inited = false;
static SemaphoreHandle_t s_status_mutex = NULL;
static i2c_port_t s_port = I2C_NUM_0;
#ifdef ALPHALOC_BATTERY_I2C_POWER_PIN
static const int s_i2c_power_pin = ALPHALOC_BATTERY_I2C_POWER_PIN;
#endif

#define I2C_MASTER_FREQ_HZ 100000
#define I2C_MASTER_TIMEOUT_MS 100

#define MAX17048_ADDR 0x36
#define LC709203F_ADDR 0x0B

#ifndef ALPHALOC_LC709203F_APA
// Type-01 LiPo adjustment for a nominal 500 mAh pack.
#define ALPHALOC_LC709203F_APA 0x10
#endif
#if ALPHALOC_LC709203F_APA < 0 || ALPHALOC_LC709203F_APA > 0xFF
#error "ALPHALOC_LC709203F_APA must fit in one byte"
#endif

static bool i2c_read_reg16(uint8_t addr, uint8_t reg, uint16_t *out) {
  uint8_t data[2] = {0};
  esp_err_t err = i2c_master_write_read_device(
      s_port, addr, &reg, 1, data, sizeof(data),
      pdMS_TO_TICKS(I2C_MASTER_TIMEOUT_MS));
  if (err != ESP_OK) {
    return false;
  }
  *out = ((uint16_t)data[0] << 8) | data[1];
  return true;
}

static bool read_max17048(float *out_voltage, float *out_percent) {
  uint16_t vcell = 0;
  uint16_t soc = 0;
  if (!i2c_read_reg16(MAX17048_ADDR, 0x02, &vcell)) {
    return false;
  }
  if (!i2c_read_reg16(MAX17048_ADDR, 0x04, &soc)) {
    return false;
  }

  float voltage = (float)vcell * 0.000078125f;
  float percent = (float)soc / 256.0f;
  *out_voltage = voltage;
  *out_percent = percent;
  return true;
}

static uint8_t lc709203f_crc8(const uint8_t *data, size_t len) {
  uint8_t crc = 0;
  for (size_t i = 0; i < len; ++i) {
    crc ^= data[i];
    for (unsigned bit = 0; bit < 8; ++bit) {
      bool high_bit = (crc & 0x80) != 0;
      crc <<= 1;
      if (high_bit) {
        crc ^= 0x07;
      }
    }
  }
  return crc;
}

static bool lc709203f_read_reg16(uint8_t reg, uint16_t *out) {
  uint8_t packet[6] = {LC709203F_ADDR << 1, reg,
                       (LC709203F_ADDR << 1) | 1, 0, 0, 0};
  esp_err_t err = i2c_master_write_read_device(
      s_port, LC709203F_ADDR, &reg, 1, packet + 3, 3,
      pdMS_TO_TICKS(I2C_MASTER_TIMEOUT_MS));
  if (err != ESP_OK) {
    return false;
  }
  if (lc709203f_crc8(packet, 5) != packet[5]) {
    ESP_LOGW(TAG, "LC709203F CRC mismatch at register 0x%02x", reg);
    return false;
  }
  *out = (uint16_t)packet[3] | ((uint16_t)packet[4] << 8);
  return true;
}

static bool lc709203f_write_reg16(uint8_t reg, uint16_t value) {
  uint8_t packet[5] = {LC709203F_ADDR << 1, reg,
                       (uint8_t)value, (uint8_t)(value >> 8), 0};
  packet[4] = lc709203f_crc8(packet, 4);
  return i2c_master_write_to_device(
             s_port, LC709203F_ADDR, packet + 1, 4,
             pdMS_TO_TICKS(I2C_MASTER_TIMEOUT_MS)) == ESP_OK;
}

static bool init_lc709203f(void) {
  if (!lc709203f_write_reg16(0x15, 0x0001)) {
    // A sleeping gauge can NACK the transaction that wakes it (TWU <= 400 us).
    // Include a full delay tick; a 1 ms delay rounds to zero at 100 Hz.
    vTaskDelay(pdMS_TO_TICKS(10) + 1);
    if (!lc709203f_write_reg16(0x15, 0x0001)) {
      return false;
    }
  }
  // Select the standard 3.7 V / 4.2 V LiPo profile; allow its reset to finish.
  if (!lc709203f_write_reg16(0x12, 0x0001)) {
    return false;
  }
  vTaskDelay(pdMS_TO_TICKS(100));
  if (!lc709203f_write_reg16(0x15, 0x0001) ||
      !lc709203f_write_reg16(0x0B, ALPHALOC_LC709203F_APA) ||
      // Feather has no battery thermistor. Assume 25 C via I2C temperature mode.
      !lc709203f_write_reg16(0x16, 0x0000) ||
      !lc709203f_write_reg16(0x08, 0x0BA6) ||
      !lc709203f_write_reg16(0x07, 0xAA55)) {
    ESP_LOGW(TAG, "LC709203F initialization failed");
    return false;
  }
  vTaskDelay(pdMS_TO_TICKS(100));
  return true;
}

static bool read_lc709203f(float *out_voltage, float *out_percent) {
  if (!s_lc709203f_inited) {
    if (!init_lc709203f()) {
      return false;
    }
    s_lc709203f_inited = true;
  }
  uint16_t vcell = 0;
  uint16_t soc = 0;
  if (!lc709203f_read_reg16(0x09, &vcell) ||
      !lc709203f_read_reg16(0x0D, &soc) || soc > 100) {
    s_lc709203f_inited = false;
    return false;
  }

  float voltage = (float)vcell * 0.001f;
  float percent = (float)soc;
  *out_voltage = voltage;
  *out_percent = percent;
  return true;
}

static void update_status(battery_monitor_t monitor, float voltage,
                          float percent, bool valid) {
  if (s_status_mutex &&
      xSemaphoreTake(s_status_mutex, pdMS_TO_TICKS(100)) != pdTRUE) {
    return;
  }
  s_status.valid = valid;
  s_status.voltage_v = voltage;
  s_status.percent = percent;
  s_status.monitor = monitor;
  s_status.last_update_us = esp_timer_get_time();
  if (s_status_mutex) {
    xSemaphoreGive(s_status_mutex);
  }
}

bool battery_init(void) {
  if (s_inited) {
    return true;
  }

  memset(&s_status, 0, sizeof(s_status));
  if (s_status_mutex == NULL) {
    s_status_mutex = xSemaphoreCreateMutex();
  }
  if (s_status_mutex == NULL) {
    ESP_LOGW(TAG, "Battery status mutex allocation failed");
    return false;
  }
  esp_err_t err;

#ifndef ALPHALOC_BATTERY_I2C_PORT
#define ALPHALOC_BATTERY_I2C_PORT 0
#endif
#ifndef ALPHALOC_BATTERY_SDA_PIN
#error "ALPHALOC_BATTERY_SDA_PIN must be set via build_flags when battery monitor is enabled"
#endif
#ifndef ALPHALOC_BATTERY_SCL_PIN
#error "ALPHALOC_BATTERY_SCL_PIN must be set via build_flags when battery monitor is enabled"
#endif
#ifdef ALPHALOC_BATTERY_I2C_POWER_PIN
  gpio_config_t pwr_cfg = {
      .pin_bit_mask = 1ULL << ALPHALOC_BATTERY_I2C_POWER_PIN,
      .mode = GPIO_MODE_OUTPUT,
      .pull_up_en = GPIO_PULLUP_DISABLE,
      .pull_down_en = GPIO_PULLDOWN_DISABLE,
      .intr_type = GPIO_INTR_DISABLE,
  };
  err = gpio_config(&pwr_cfg);
  if (err == ESP_OK) {
    err = gpio_set_level(s_i2c_power_pin, 0);
  }
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "Battery I2C power config failed: %s", esp_err_to_name(err));
    vSemaphoreDelete(s_status_mutex);
    s_status_mutex = NULL;
    return false;
  }
#endif

  s_port = (i2c_port_t)ALPHALOC_BATTERY_I2C_PORT;
  i2c_config_t cfg = {
      .mode = I2C_MODE_MASTER,
      .sda_io_num = ALPHALOC_BATTERY_SDA_PIN,
      .scl_io_num = ALPHALOC_BATTERY_SCL_PIN,
      .sda_pullup_en = GPIO_PULLUP_ENABLE,
      .scl_pullup_en = GPIO_PULLUP_ENABLE,
      .master.clk_speed = I2C_MASTER_FREQ_HZ,
  };
  err = i2c_param_config(s_port, &cfg);
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "I2C param config failed: %s", esp_err_to_name(err));
    vSemaphoreDelete(s_status_mutex);
    s_status_mutex = NULL;
    return false;
  }
  err = i2c_driver_install(s_port, I2C_MODE_MASTER, 0, 0, 0);
  if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
    ESP_LOGW(TAG, "I2C driver install failed: %s", esp_err_to_name(err));
    vSemaphoreDelete(s_status_mutex);
    s_status_mutex = NULL;
    return false;
  }

  s_inited = true;
  return true;
}

bool battery_read_now(void) {
  if (!s_inited && !battery_init()) {
    return false;
  }

#ifdef ALPHALOC_BATTERY_I2C_POWER_PIN
  esp_err_t err = gpio_set_level(s_i2c_power_pin, 1);
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "Battery I2C power enable failed: %s", esp_err_to_name(err));
    s_lc709203f_inited = false;
    update_status(BATTERY_MONITOR_NONE, 0.0f, 0.0f, false);
    return false;
  }
  vTaskDelay(pdMS_TO_TICKS(10) + 1);
#endif

  float voltage = 0.0f;
  float percent = 0.0f;
  battery_monitor_t monitor = BATTERY_MONITOR_NONE;
  if (read_max17048(&voltage, &percent)) {
    monitor = BATTERY_MONITOR_MAX17048;
  } else if (read_lc709203f(&voltage, &percent)) {
    monitor = BATTERY_MONITOR_LC709203F;
  }

  // Reject zero or implausible cell voltages, including unpowered gauges.
  bool valid = monitor != BATTERY_MONITOR_NONE &&
               voltage >= 2.5f && voltage <= 4.5f;
#ifdef ALPHALOC_BATTERY_I2C_POWER_PIN
  err = gpio_set_level(s_i2c_power_pin, 0);
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "Battery I2C power disable failed: %s", esp_err_to_name(err));
    valid = false;
  }
#endif
  if (!valid) {
    s_lc709203f_inited = false;
    update_status(BATTERY_MONITOR_NONE, 0.0f, 0.0f, false);
#if ALPHALOC_VERBOSE
    ESP_LOGI(TAG, "Battery reading unavailable");
#endif
    return false;
  }
  update_status(monitor, voltage, percent, true);
#if ALPHALOC_VERBOSE
  ESP_LOGI(TAG, "Battery %s: %.2fV %.0f%%",
           monitor == BATTERY_MONITOR_MAX17048 ? "MAX17048" : "LC709203F",
           (double)voltage, (double)percent);
#endif
  return true;
}

bool battery_get_status(battery_status_t *out) {
  if (!out) {
    return false;
  }
  if (s_status_mutex &&
      xSemaphoreTake(s_status_mutex, pdMS_TO_TICKS(100)) != pdTRUE) {
    return false;
  }
  *out = s_status;
  bool valid = s_status.valid;
  if (s_status_mutex) {
    xSemaphoreGive(s_status_mutex);
  }
  return valid;
}

#else

bool battery_init(void) { return false; }
bool battery_read_now(void) { return false; }
bool battery_get_status(battery_status_t *out) {
  if (out) {
    memset(out, 0, sizeof(*out));
  }
  return false;
}

#endif
