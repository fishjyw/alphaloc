// Minimal M5PM1 power control for M5StickS3.
// M5PM1 sits on I2C at 0x6E. On M5StickS3 the internal I2C is
// SDA = GPIO47, SCL = GPIO48. Setting bit 3 (BOOST_EN) of register
// 0x06 (PWR_CFG) turns on the BOOST/Grove 5V rail that feeds PORT.A.

#include "m5pm1_power.h"

#include "driver/i2c_master.h"
#include "esp_log.h"

static const char *TAG = "m5pm1_power";

#ifndef M5PM1_I2C_ADDR
#define M5PM1_I2C_ADDR 0x6E
#endif
#ifndef M5PM1_SDA_PIN
#define M5PM1_SDA_PIN 47
#endif
#ifndef M5PM1_SCL_PIN
#define M5PM1_SCL_PIN 48
#endif

#define M5PM1_REG_PWR_CFG 0x06
#define M5PM1_PWR_CFG_BOOST_EN (1 << 3)

void m5pm1_grove_5v_enable(void) {
  i2c_master_bus_handle_t bus = NULL;
  i2c_master_dev_handle_t dev = NULL;

  i2c_master_bus_config_t bus_cfg = {
      .i2c_port = I2C_NUM_0,
      .sda_io_num = M5PM1_SDA_PIN,
      .scl_io_num = M5PM1_SCL_PIN,
      .clk_source = I2C_CLK_SRC_DEFAULT,
      .glitch_ignore_cnt = 7,
      .flags.enable_internal_pullup = true,
  };
  esp_err_t err = i2c_new_master_bus(&bus_cfg, &bus);
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "i2c bus init failed: %s", esp_err_to_name(err));
    return;
  }

  i2c_device_config_t dev_cfg = {
      .dev_addr_length = I2C_ADDR_BIT_LEN_7,
      .device_address = M5PM1_I2C_ADDR,
      .scl_speed_hz = 100000,
  };
  err = i2c_master_bus_add_device(bus, &dev_cfg, &dev);
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "i2c add device failed: %s", esp_err_to_name(err));
    i2c_del_master_bus(bus);
    return;
  }

  // Probe the PMIC; if it doesn't answer, this isn't an M5StickS3 (or no PMIC).
  err = i2c_master_probe(bus, M5PM1_I2C_ADDR, 100);
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "M5PM1 not found at 0x%02X: %s (Grove 5V left as-is)",
             M5PM1_I2C_ADDR, esp_err_to_name(err));
    i2c_master_bus_rm_device(dev);
    i2c_del_master_bus(bus);
    return;
  }

  // Read-modify-write PWR_CFG: set BOOST_EN, preserve other bits.
  uint8_t reg = M5PM1_REG_PWR_CFG;
  uint8_t val = 0;
  err = i2c_master_transmit_receive(dev, &reg, 1, &val, 1, 100);
  if (err == ESP_OK) {
    uint8_t new_val = val | M5PM1_PWR_CFG_BOOST_EN;
    uint8_t buf[2] = {M5PM1_REG_PWR_CFG, new_val};
    err = i2c_master_transmit(dev, buf, 2, 100);
    if (err == ESP_OK) {
      ESP_LOGI(TAG, "Grove 5V enabled (PWR_CFG 0x%02X -> 0x%02X)", val, new_val);
    } else {
      ESP_LOGW(TAG, "write PWR_CFG failed: %s", esp_err_to_name(err));
    }
  } else {
    ESP_LOGW(TAG, "read PWR_CFG failed: %s", esp_err_to_name(err));
  }

  i2c_master_bus_rm_device(dev);
  i2c_del_master_bus(bus);
}
