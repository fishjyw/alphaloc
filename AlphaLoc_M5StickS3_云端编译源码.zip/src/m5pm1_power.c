// Minimal M5PM1 power control for M5StickS3 (ESP-IDF 4.4 legacy I2C API).
// M5PM1 sits on I2C at 0x6E. On M5StickS3 the internal I2C is
// SDA = GPIO47, SCL = GPIO48. Setting bit 3 (BOOST_EN) of register
// 0x06 (PWR_CFG) turns on the BOOST/Grove 5V rail that feeds PORT.A.

#include "m5pm1_power.h"

#include "driver/gpio.h"
#include "driver/i2c.h"
#include "esp_err.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"

static const char *TAG = "m5pm1_power";

#ifndef M5PM1_I2C_ADDR
#define M5PM1_I2C_ADDR 0x6E
#endif
#ifndef M5PM1_SDA_PIN
#define M5PM1_SDA_PIN 47
#endif
#ifndef M5PM1_SCL_PIN
#define M5PM1_SCL_PIN 48
#endif
#ifndef M5PM1_I2C_PORT
#define M5PM1_I2C_PORT I2C_NUM_0
#endif

#define M5PM1_REG_PWR_CFG 0x06
#define M5PM1_PWR_CFG_BOOST_EN (1 << 3)
#define M5PM1_I2C_FREQ_HZ 100000
#define M5PM1_TIMEOUT_MS 100

void m5pm1_grove_5v_enable(void) {
  i2c_port_t port = (i2c_port_t)M5PM1_I2C_PORT;

  i2c_config_t cfg = {
      .mode = I2C_MODE_MASTER,
      .sda_io_num = M5PM1_SDA_PIN,
      .scl_io_num = M5PM1_SCL_PIN,
      .sda_pullup_en = GPIO_PULLUP_ENABLE,
      .scl_pullup_en = GPIO_PULLUP_ENABLE,
      .master.clk_speed = M5PM1_I2C_FREQ_HZ,
  };
  esp_err_t err = i2c_param_config(port, &cfg);
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "i2c param config failed: %s", esp_err_to_name(err));
    return;
  }
  err = i2c_driver_install(port, I2C_MODE_MASTER, 0, 0, 0);
  if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
    ESP_LOGW(TAG, "i2c driver install failed: %s", esp_err_to_name(err));
    return;
  }

  // Probe the PMIC; if it doesn't answer, this isn't an M5StickS3 (or no PMIC).
  err = i2c_master_probe(port, M5PM1_I2C_ADDR, M5PM1_TIMEOUT_MS);
  if (err != ESP_OK) {
    ESP_LOGW(TAG, "M5PM1 not found at 0x%02X: %s (Grove 5V left as-is)",
             M5PM1_I2C_ADDR, esp_err_to_name(err));
    return;
  }

  // Read-modify-write PWR_CFG: set BOOST_EN, preserve other bits.
  uint8_t reg = M5PM1_REG_PWR_CFG;
  uint8_t val = 0;
  err = i2c_master_write_read_device(port, M5PM1_I2C_ADDR, &reg, 1, &val, 1,
                                     pdMS_TO_TICKS(M5PM1_TIMEOUT_MS));
  if (err == ESP_OK) {
    uint8_t new_val = val | M5PM1_PWR_CFG_BOOST_EN;
    uint8_t buf[2] = {M5PM1_REG_PWR_CFG, new_val};
    err = i2c_master_write_to_device(port, M5PM1_I2C_ADDR, buf, 2,
                                     pdMS_TO_TICKS(M5PM1_TIMEOUT_MS));
    if (err == ESP_OK) {
      ESP_LOGI(TAG, "Grove 5V enabled (PWR_CFG 0x%02X -> 0x%02X)", val, new_val);
    } else {
      ESP_LOGW(TAG, "write PWR_CFG failed: %s", esp_err_to_name(err));
    }
  } else {
    ESP_LOGW(TAG, "read PWR_CFG failed: %s", esp_err_to_name(err));
  }
}
